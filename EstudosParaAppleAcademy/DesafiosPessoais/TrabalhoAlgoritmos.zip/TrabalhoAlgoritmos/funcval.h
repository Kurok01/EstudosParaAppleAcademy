#ifndef FUNCVAL_H
#define FUNCVAL_H

int func_val(int x, int b);

#endif
