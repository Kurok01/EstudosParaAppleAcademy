#ifndef DECIFRACODIGO_H
#define DECIFRACODIGO_H

void decifraCodigo (char texto[], int b);

void scanearCodigo(char texto[]);

#endif
